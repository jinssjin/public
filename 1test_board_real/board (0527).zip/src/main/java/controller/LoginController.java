package controller;

import java.io.IOException;
import java.util.ArrayList;

import model.LoginDAO;
import model.LoginDTO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.BoardDAO;
import model.BoardDTO;

public class LoginController extends HttpServlet {
   private static final long serialVersionUID = 1L;
   static final int LISTCOUNT = 5; 

   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doPost(request, response);
   }

   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      String RequestURI = request.getRequestURI();
      String contextPath = request.getContextPath();
      String command = RequestURI.substring(contextPath.length());
      response.setContentType("text/html; charset=UTF-8");
      request.setCharacterEncoding("UTF-8");
   
      if (command.equals("/login/loginAction.do")) {  // 로그인
    	  checkLogin(request,response);
      }else if(command.equals("/login/signUp.do")) {  // 회원가입폼
    	  RequestDispatcher rd = request.getRequestDispatcher("/login/signup.jsp");
    	  rd.forward(request, response);
      }else if(command.equals("/login/signUpAction.do")) {  // 회원가입
    	  createId(request,response);
      }else if (command.equals("/login/updateMember.do")) {  // 회원정보 수정폼 불러오기
    	  	requestUpdateMember(request);
    	  	RequestDispatcher rd = request.getRequestDispatcher("/login/updateMember.jsp");
			rd.forward(request, response);
      }else if (command.equals("/login/updateMemberAction.do")) {  // 회원정보 수정
    	  	updateUserById(request,response);
    	  	response.sendRedirect(request.getContextPath() + "/index");
      }else if (command.equals("/login/logout.do")) {  // 로그아웃
    	    logout(request, response);
      }else if (command.equals("/login/deleteMember.do")) {  // 회원탈퇴
    	    deleteAccount(request, response);
      }
   }
      
      
      
      
  // 메서드 영역
      
  // 로그인 체크 메서드
  public void checkLogin(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
  // login.jsp에서 form으로 받아온 아이디와 패스워드
  String userId = request.getParameter("userId");
  String password = request.getParameter("password");
  
  // LoginDTO 객체를 생성해서 받아온 아이디와 패스워드를 넣어주고 
  LoginDTO loginDto = new LoginDTO();
  loginDto.setUserId(userId);
  loginDto.setPassword(password);
  
  // 로그인 체크 매서드로 확인 (참값 혹은 거짓)
  LoginDAO loginDao = LoginDAO.getInstance();
  boolean isValid = loginDao.loginCheck(loginDto);
  
  // 세션에 유저 정보 저장
  if (isValid) {
      HttpSession session = request.getSession();
      session.setAttribute("sessionId", userId);
      response.sendRedirect("login/success.jsp");
  } else {
      response.sendRedirect("login/fail.jsp");
  }
}
  
  // 회원가입
  public void createId(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    String userId = request.getParameter("userId");
	    String password = request.getParameter("password");
	    String name = request.getParameter("name");
	    String email = request.getParameter("email");
	    String phone = request.getParameter("phone");
	    String address = request.getParameter("address");

	   
	    LoginDTO dto = new LoginDTO();
	    dto.setUserId(userId);
	    dto.setPassword(password);
	    dto.setUserName(name);
	    dto.setUserEmail(email);
	    dto.setUserPhone(phone);
	    dto.setUserAddress(address);

	    LoginDAO dao = LoginDAO.getInstance();
	    boolean result = dao.createId(dto);

	    if (result) {
	        response.sendRedirect(request.getContextPath() + "/index.jsp");
	    } else {
	        response.sendRedirect(request.getContextPath() + "/login/signUpFail.jsp");
	    }
	}

  
  // 멤버 업데이트
  public void requestUpdateMember(HttpServletRequest request) {
	  	String sessionId = (String) request.getSession().getAttribute("sessionId");
		LoginDTO user = LoginDAO.getInstance().getUserById(sessionId);
		request.setAttribute("user", user);
  }
  
  public void updateUserById(HttpServletRequest request, HttpServletResponse response)
	        throws IOException {
	    String userId = request.getParameter("userId");
	    String password = request.getParameter("password");
	    String name = request.getParameter("name");
	    String email = request.getParameter("email");
	    String phone = request.getParameter("phone");
	    String address = request.getParameter("address");

	    LoginDTO dto = new LoginDTO();
	    dto.setUserId(userId);
	    dto.setPassword(password);
	    dto.setUserName(name);
	    dto.setUserEmail(email);
	    dto.setUserPhone(phone);
	    dto.setUserAddress(address);

	    LoginDAO dao = LoginDAO.getInstance();
	    boolean result = dao.updateUser(dto); // 이 메서드도 DAO에 구현 필요

	    if (result) {
	        response.sendRedirect(request.getContextPath() + "/index.jsp");
	    } else {
	        response.sendRedirect(request.getContextPath() + "/login/updateFail.jsp");
	    }
	}
  
  public void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
	    HttpSession session = request.getSession(false);  // 현재 세션이 없으면 null 반환
	    if (session != null) {
	        session.invalidate(); // 세션 무효화
	    }
	    response.sendRedirect(request.getContextPath() + "/index.jsp"); // 메인페이지로 이동
	}
  
  public void deleteAccount(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	    String sessionId = (String) request.getSession().getAttribute("sessionId");

	    if (sessionId != null) {
	        LoginDAO dao = LoginDAO.getInstance();
	        boolean result = dao.deleteUserById(sessionId);

	        if (result) {
	            // 세션 종료
	            HttpSession session = request.getSession(false);
	            if (session != null) session.invalidate();

	            // 탈퇴 성공 페이지로 이동
	            response.sendRedirect(request.getContextPath() + "/login/deleteIdSuccess.jsp");
	        } else {
	            // 실패 시 알림 또는 에러 페이지로 이동
	            response.sendRedirect(request.getContextPath() + "/login/deleteIdFail.jsp");
	        }
	    } else {
	        response.sendRedirect(request.getContextPath() + "/login/login.jsp");
	    }
	}
}
  
  
  
