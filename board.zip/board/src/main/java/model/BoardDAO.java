package model;

public class BoardDAO {
	
	

}
