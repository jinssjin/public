package model;

public class LoginDAO {

}
